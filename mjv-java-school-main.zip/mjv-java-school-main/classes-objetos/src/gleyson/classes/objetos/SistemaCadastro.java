package gleyson.classes.objetos;

public class SistemaCadastro {
	public static void main(String[] args) {
		
		
		
	}
}
