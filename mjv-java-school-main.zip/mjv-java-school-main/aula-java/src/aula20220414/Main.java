package aula20220414;

public class Main {
	public static void main(String[] args) {
		System.out.println("Meu primeiro projeto Java");
	}
}
