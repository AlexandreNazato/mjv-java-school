package aula20220414;

public class TiposPrimitivos {
	//variaveis de classes numerica recebe valor padrao zero
	static int numero;
	static boolean simNao;
	static char cchar;
	
	public static void main(String[] args) {
		//prq variavel local de metodo precisa ser inicializada?
		
	}
	
}
