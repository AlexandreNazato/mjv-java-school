package aula20220414;

public class EstudandoString {
	public static void main(String[] args) {
		//COLOCAR TODAS AS PALAVRAS MINUSCULAS
		String palavra = "GLEYSON SAMPAIO";
		System.out.println(palavra.toLowerCase());
	}
}
