package aula20220414;

public class AulaVariaveis {
	public static void main(String[] args) {
		final String PALAVRA = " GLEYSON ";
		System.out.println(PALAVRA);
		
	}
	
}
